Udacity Programming for Data Science with Python Nanodegree:
Project 2: Explore US Bikeshare Data

Sources of reference and informations:
Python Documentation
StackOverflow
Superuser
pandas Documentation
w3Schools
programiz
geeksforgeeks
