import time
import pandas as pd
import numpy as np

CITY_DATA = {
    'chicago': 'chicago.csv',
    'new york city': 'new_york_city.csv',
    'washington': 'washington.csv'}

MONTHS = ['january', 'february', 'march', 'april', 'may', 'june']
WEEKDAYS = [
    'monday',
    'tuesday',
    'wednesday',
    'thursday',
    'friday',
    'saturday',
    'sunday']


LINE_LEN = 90

# printing stars to separate the outputs


def print_line(char): return print(char[0] * LINE_LEN)


def print_processing_time(start_time):
    time_str = "[%s seconds]" % round((time.time() - start_time), 4)
    print(time_str.rjust(LINE_LEN))
    print_line('*')


def get_filter_city():
    """
    Asking user to specify a city.

    Returns:
        (str) city - user specified city.
    """
    # display list of cities to choose from
    cities_list = []
    num_cities = 0

    for a_city in CITY_DATA:
        cities_list.append(a_city)
        num_cities += 1
        print('        {0}: {1}'.format(num_cities, a_city.title()))

    # user inputs city number as it's easier and shorter

    while True:
        try:
            city_num = int(input(
                "\n    Enter the number of city from [1] - [{}]:  ".format(len(cities_list))))
        except BaseException:
            continue

        if city_num in range(1, len(cities_list) + 1):
            break

    # returning city's name/s
    city = cities_list[city_num - 1]
    return city


def get_filter_month():
    """
    Asking user to specify a month or select all.

    Returns:
        (str) month - user specified month or all.
    """
    while True:
        try:
            month = input(
                "    Enter the number of month from January[1] to June[6] or 'all'|'a':  ")
        except BaseException:
            continue

        if month.lower() == 'a' or month.lower() == 'all':
            month = 'all'
            break
        elif month in {'1', '2', '3', '4', '5', '6'}:
            # returning month's name/s
            month = MONTHS[int(month) - 1]
            break
        else:
            continue

    return month


def get_filter_day():
    """
    Asking user to specify a day select all.

    Returns:
        (str) day - user specified day or all.
    """
    while True:
        try:
            day = input(
                "    Enter the number of day from Monday[1] to Sunday[7] or 'all'|'a':  ")
        except BaseException:
            continue

        if day.lower() == 'a' or day.lower() == 'all':
            day = 'all'
            break
        elif day in {'1', '2', '3', '4', '5', '6', '7'}:
            # returning day's name/s
            day = WEEKDAYS[int(day) - 1]
            break
        else:
            continue

    return day


def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print_line('=')
    print('\n  Hello! Let\'s explore some US bikeshare data!\n')
    # get user input for city (chicago, new york city, washington).

    city = get_filter_city()

    # get user input for month (all, january, february, ... , june)
    month = get_filter_month()

    # get user input for day of week (all, monday, tuesday, ... sunday)
    day = get_filter_day()

    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    start_time = time.time()

    # loading file into dataframe
    df = pd.read_csv(CITY_DATA[city])

    # converting Start Time to datetime
    df['Start Time'] = pd.to_datetime(df['Start Time'], errors='coerce')

    # creating new columns in dataframe
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.dayofweek
    df['hour'] = df['Start Time'].dt.hour

    init_total_rides = len(df)
    filtered_rides = init_total_rides

    # filtering by specified month
    if month != 'all':

        month_i = MONTHS.index(month) + 1

        # creating new dataframe filtered by specified month
        df = df[df.month == month_i]
        month = month.title()

    # filter by specified week
    if day != 'all':

        day_i = WEEKDAYS.index(day)

        # creating new dataframe filtered by specified day
        df = df[df.day_of_week == day_i]
        day = day.title()

    filtered_rides = len(df)
    num_stations_start = len(df['Start Station'].unique())
    num_stations_end = len(df['End Station'].unique())

    print('\n    Selected City:              ', city)
    print('    Selected month, day:        ', month, ', ', day)
    print('    Actual rides in dataset:    ', init_total_rides)
    print('    Rides in filtered set:      ', filtered_rides)
    print('    Start stations:         ', num_stations_start)
    print('    End stations:           ', num_stations_end)

    print_processing_time(start_time)

    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    month = MONTHS[df['month'].mode()[0] - 1].title()
    print('    Month:               ', month)

    # display the most common day of week
    common_day = df['day_of_week'].mode()[0]
    common_day = WEEKDAYS[common_day].title()
    print('    Day of the week:     ', common_day)

    # display the most common start hour
    hour = df['hour'].mode()[0]
    if hour == 0:
        hour = '12 AM'
    elif hour == 12:
        hour = '12 PM'
    else:
        hour = '{} AM'.format(
            hour) if hour < 12 else '{} PM'.format(hour - 12)
    print('    Start hour:          ', hour)

    print_processing_time(start_time)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    filtered_rides = len(df)

    # display most commonly used start station
    start_station = df['Start Station'].mode()[0]
    start_station_trips = df['Start Station'].value_counts()[start_station]

    print('    Start station:    ', start_station)
    print('{0:25}{1}/{2} trips'.format(' ', start_station_trips, filtered_rides))

    # display most commonly used end station
    end_station = df['End Station'].mode()[0]
    end_station_trips = df['End Station'].value_counts()[end_station]

    print('    End station:      ', end_station)
    print('{0:25}{1}/{2} trips'.format(' ', end_station_trips, filtered_rides))

    # display most frequent combination of start station and end station trip
    df_start_end_combination_gd = df.groupby(['Start Station', 'End Station'])
    most_freq_trip_count = df_start_end_combination_gd['Trip Duration'].count(
    ).max()
    most_freq_trip = df_start_end_combination_gd['Trip Duration'].count(
    ).idxmax()

    print('    Frequent trip:     {}, {}'.format(
        most_freq_trip[0], most_freq_trip[1]))
    print('{0:25} {1} trips.'.format(' ', most_freq_trip_count))

    print_processing_time(start_time)


def seconds_to_HMS_str(total_seconds):
    """
    Converting seconds to weeks, days, hours and minutes.

    Args:
        (int) total_seconds
    Returns:
        (str) day_hour_str - converted string in w,d,h,m
    """

    minutes, seconds = divmod(total_seconds, 60)
    hours, minutes = divmod(minutes, 60)
    days, hours = divmod(hours, 24)
    weeks, days = divmod(days, 7)

    day_hour_str = ''
    if weeks > 0:
        day_hour_str += '{} weeks, '.format(weeks)
    if days > 0:
        day_hour_str += '{} days, '.format(days)
    if hours > 0:
        day_hour_str += '{} hours, '.format(hours)
    if minutes > 0:
        day_hour_str += '{} minutes, '.format(minutes)
    if total_seconds > 59:
        day_hour_str += '{} seconds'.format(seconds)

    return day_hour_str


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    total_travel_time = int(df['Trip Duration'].sum())
    print('    Total travel time:    ', seconds_to_HMS_str(total_travel_time))

    # display mean travel time
    mean_travel_time = int(df['Trip Duration'].mean())
    print('    Mean travel time:    ', seconds_to_HMS_str(mean_travel_time))

    print_processing_time(start_time)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_types = df['User Type'].value_counts()
    for idx in range(len(user_types)):
        val = user_types[idx]
        user_type = user_types.index[idx]
        print('    {0:21}'.format((user_type + ':')), val)

    # Display counts of gender, only applicable for Chicago and NYC

    if 'Gender' in df.columns:
        genders = df['Gender'].value_counts()
        for idx in range(len(genders)):
            val = genders[idx]
            gender = genders.index[idx]
            print('    {0:21}'.format((gender + ':')), val)

    # Display earliest, most recent, and most common year of birth

    if 'Birth Year' in df.columns:
        print('        Year of Births:')
        print('\n        Oldest:        ', int(df['Birth Year'].min()))
        print('        Youngest:     ', int(df['Birth Year'].max()))
        print('        Most common:     ', int(df['Birth Year'].mode()))

    print_processing_time(start_time)


def display_raw_data(df):
    """
    Asking the user if they want to see first 5 lines from the filtered dataset,
    he can continue seeing next lines in the multiple of 5 until he wishes to stop.

    """
    show_rows = 5
    rows_start = 0
    rows_end = show_rows - 1

    print('\n    Would you like to get raw data from the dataset?')
    while True:
        raw_data = input('      (yes or no?):      ')
        # Display data, actual index + 1.
        if raw_data.lower() == 'y' or raw_data.lower() == 'yes':
            print(
                '\n    Displaying rows {} - {}:'.format(
                    rows_start + 1,
                    rows_end + 1))

            print('\n', df.iloc[rows_start: rows_end + 1])
            rows_start += show_rows
            rows_end += show_rows

            print_line('~')
            print('\n    Would you like to see the next {} rows?'.format(show_rows))
            continue
        else:
            break


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)
        time.sleep(2)
        time_stats(df)
        time.sleep(2)
        station_stats(df)
        time.sleep(2)
        trip_duration_stats(df)
        time.sleep(2)
        user_stats(df)
        time.sleep(2)
        display_raw_data(df)

        restart = input(
            '\n    Would you like to get another data? (yes or no?):  ')
        if restart.lower() != 'yes' or restart.lower() != 'y':
            print('\n    Thank You! ')
            break


if __name__ == "__main__":
    main()
